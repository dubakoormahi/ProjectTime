package com.DAO.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DB.util.LoginUser;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String userName = request.getParameter("username");
		String passWord = request.getParameter("password");
		String uType = validateservlet(userName, passWord);
		if (uType != null) {
			HttpSession session = request.getSession();
			String uName[] = LoginUser.getUserName(userName, uType);
			session.setAttribute("userName", userName);
			session.setAttribute("realName", uName[0]);
			session.setAttribute("teamName", uName[1]);
			session.setAttribute("baseLoc", uName[2]);
			session.setAttribute("userType", uType);
			if (uType.equalsIgnoreCase("member"))
				response.sendRedirect("newsFeed.jsp");
			else if (uType.equalsIgnoreCase("leader"))
				response.sendRedirect("newsFeed1.jsp");
		} else {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Sorry couldnot Login!!!');");
			out.println("location='Login.jsp';");
			out.println("</script>");
		}
	}

	String validateservlet(String userName, String passWord) {
		String validd = LoginUser.loginUser(userName, passWord);
		if (validd != null) {
			return validd;
		} else {
			return null;
		}
	}

}
