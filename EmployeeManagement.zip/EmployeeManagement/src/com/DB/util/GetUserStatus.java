package com.DB.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.DB.ConnectionManager.GetConnection;
import com.basic.BeanModules.StatusBean;

public class GetUserStatus {
	public List<StatusBean> getstatus(String teamname) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<StatusBean> statuslist = new ArrayList<>();
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = "select * from LocationDetails where team='"
						+ teamname
						+ "' and reason='Travel Plans' order by location";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					StatusBean sb = new StatusBean();
					String empid = rs.getString("empId");
					sb.setEmpID(empid);
					String loc = rs.getString("location");
					sb.setLocation(loc);
					Statement stmt1 = conn.createStatement();
					ResultSet rs1 = stmt1
							.executeQuery("select * from ColorMatch where location='"
									+ loc + "'");
					while (rs1.next()) {
						sb.setBgcolor(rs1.getString("color"));
						sb.setTxtcolor(rs1.getString("text_color"));
					}
					Statement stmt2 = conn.createStatement();
					ResultSet rs2 = stmt2
							.executeQuery("select * from EmpDetails where empid='"
									+ empid + "'");
					while (rs2.next()) {
						sb.setCurrLocation(rs2.getString("location"));
					}
					String frmdat[]=rs.getString("frmdate").split("-");
					String frmmdate=frmdat[2]+"-"+frmdat[1]+"-"+frmdat[0];
					String todat[]=rs.getString("todate").split("-");
					String toodate=todat[2]+"-"+todat[1]+"-"+todat[0];
					sb.setFromDate(frmmdate);
					sb.setToDate(toodate);
					sb.setReason(rs.getString("reason"));
					statuslist.add(sb);
				}
				return statuslist;
			} catch (Exception e) {
				return null;
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return statuslist;
	}

	public List<StatusBean> getTransstatus(String teamname) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<StatusBean> statuslist = new ArrayList<>();
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = "select * from LocationDetails where team='"
						+ teamname
						+ "' and reason='Transfers' order by location";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					StatusBean sb = new StatusBean();
					String empid = rs.getString("empId");
					sb.setEmpID(empid);
					String loc = rs.getString("location");
					sb.setLocation(loc);
					Statement stmt1 = conn.createStatement();
					ResultSet rs1 = stmt1
							.executeQuery("select * from ColorMatch where location='"
									+ loc + "'");
					while (rs1.next()) {
						sb.setBgcolor(rs1.getString("color"));
						sb.setTxtcolor(rs1.getString("text_color"));
					}
					Statement stmt2 = conn.createStatement();
					ResultSet rs2 = stmt2
							.executeQuery("select * from EmpDetails where empid='"
									+ empid + "'");
					while (rs2.next()) {
						sb.setCurrLocation(rs2.getString("location"));
					}
					String frmdat[]=rs.getString("frmdate").split("-");
					String frmmdate=frmdat[2]+"-"+frmdat[1]+"-"+frmdat[0];
					String todat[]=rs.getString("todate").split("-");
					String toodate=todat[2]+"-"+todat[1]+"-"+todat[0];
					sb.setFromDate(frmmdate);
					sb.setToDate(toodate);
					sb.setReason(rs.getString("reason"));
					statuslist.add(sb);
				}
				return statuslist;
			} catch (Exception e) {
				return null;
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return statuslist;
	}

	public List<StatusBean> getallstatus(String teamname) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<StatusBean> statuslist = new ArrayList<>();
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = "select * from LocationDetails where team='"
						+ teamname + "' order by location";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					StatusBean sb = new StatusBean();
					String empid = rs.getString("empId");
					sb.setEmpID(empid);
					String loc = rs.getString("location");
					sb.setLocation(loc);
					Statement stmt1 = conn.createStatement();
					ResultSet rs1 = stmt1
							.executeQuery("select * from ColorMatch where location='"
									+ loc + "'");
					while (rs1.next()) {
						sb.setBgcolor(rs1.getString("color"));
						sb.setTxtcolor(rs1.getString("text_color"));
					}
					Statement stmt2 = conn.createStatement();
					ResultSet rs2 = stmt2
							.executeQuery("select * from EmpDetails where empid='"
									+ empid + "'");
					while (rs2.next()) {
						sb.setCurrLocation(rs2.getString("location"));
					}
					String frmdat[]=rs.getString("frmdate").split("-");
					String frmmdate=frmdat[2]+"-"+frmdat[1]+"-"+frmdat[0];
					String todat[]=rs.getString("todate").split("-");
					String toodate=todat[2]+"-"+todat[1]+"-"+todat[0];
					sb.setFromDate(frmmdate);
					sb.setToDate(toodate);
					sb.setReason(rs.getString("reason"));
					statuslist.add(sb);
				}
				return statuslist;
			} catch (Exception e) {
				return null;
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return statuslist;
	}

	public List<StatusBean> getmystatus(String uName) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<StatusBean> statuslist = new ArrayList<>();
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = "select * from LocationDetails where empID='"
						+ uName + "' order by location";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					StatusBean sb = new StatusBean();
					String empid = rs.getString("empId");
					sb.setEmpID(empid);
					String loc = rs.getString("location");
					sb.setLocation(loc);
					Statement stmt1 = conn.createStatement();
					ResultSet rs1 = stmt1
							.executeQuery("select * from ColorMatch where location='"
									+ loc + "'");
					while (rs1.next()) {
						sb.setBgcolor(rs1.getString("color"));
						sb.setTxtcolor(rs1.getString("text_color"));
					}
					Statement stmt2 = conn.createStatement();
					ResultSet rs2 = stmt2
							.executeQuery("select * from EmpDetails where empid='"
									+ empid + "'");
					while (rs2.next()) {
						sb.setCurrLocation(rs2.getString("location"));
					}
					String frmdat[]=rs.getString("frmdate").split("-");
					String frmmdate=frmdat[2]+"-"+frmdat[1]+"-"+frmdat[0];
					String todat[]=rs.getString("todate").split("-");
					String toodate=todat[2]+"-"+todat[1]+"-"+todat[0];
					sb.setFromDate(frmmdate);
					sb.setToDate(toodate);
					sb.setReason(rs.getString("reason"));
					statuslist.add(sb);
				}
				return statuslist;
			} catch (Exception e) {
				return null;
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return statuslist;
	}
}
