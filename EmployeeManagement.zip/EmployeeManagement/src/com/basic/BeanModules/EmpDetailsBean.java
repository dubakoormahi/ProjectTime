package com.basic.BeanModules;

public class EmpDetailsBean {
	private String EmpID;
	private String name;
	private String emailID;
	private String ContactNo;
	private String BaseLoc;

	public String getEmpID() {
		return EmpID;
	}

	public void setEmpID(String empID) {
		EmpID = empID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getContactNo() {
		return ContactNo;
	}

	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}

	public String getBaseLoc() {
		return BaseLoc;
	}

	public void setBaseLoc(String baseLoc) {
		BaseLoc = baseLoc;
	}

}
