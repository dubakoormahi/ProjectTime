--create
create table T_XBBNHG2_EmpCredentials(username varchar(20) primary key,password varchar(20),usertype varchar(20));
create table T_XBBNHG2_EmpDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teammanager varchar2(30));
create table T_XBBNHG2_LeadDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));
create table T_XBBNHG2_LocationDetails(empID varchar(20),location varchar(30), frmdate varchar(12), todate varchar(12),team varchar(30));

alter table T_XBBNHG2_EmpDetails add teamname varchar2(30);
update T_XBBNHG2_EmpDetails set teamname='TT01' where empid='EM001';
alter table T_XBBNHG2_EmpDetails drop column teammanager;
drop table T_XBBNHG2_ColorMatch;
create table T_XBBNHG2_ColorMatch(Location varchar(30),color varchar(20),text_color varchar(30));
insert into T_XBBNHG2_ColorMatch values('Chennai','yellow','black');
insert into T_XBBNHG2_ColorMatch values('Mumbai','Green','White');
insert into T_XBBNHG2_ColorMatch values('Pune','Pink','White');
insert into T_XBBNHG2_ColorMatch values('Delhi','Blue','White');
insert into T_XBBNHG2_ColorMatch values('Bangalore','red','white');
insert into T_XBBNHG2_ColorMatch values('Noida','orange','black');

--select
select * from T_XBBNHG2_EmpCredentials;
select * from T_XBBNHG2_EmpDetails;
select * from T_XBBNHG2_LeadDetails;
select * from T_XBBNHG2_LocationDetails;

--truncate
truncate table T_XBBNHG2_LeadDetails;
truncate table T_XBBNHG2_EmpDetails;
truncate table T_XBBNHG2_EmpCredentials;
--drop
drop table T_XBBNHG2_LeadDetails;
drop table T_XBBNHG2_EmpDetails;
drop table T_XBBNHG2_EmpCredentials;
----------------------------------------------------------------
alter table T_XBBNHG2_EmpDetails add(lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30),teammanager varchar2(30));
----------------------------------------------------------------
CREATE TABLE T_XBBNHG2_LeadDetails AS (SELECT * FROM T_XBBNHG2_EmpCredentials);
create table T_XBBNHG2_LeadDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));

ALTER TABLE T_XBBNHG2_EmpDetails ADD teamname varchar2(30);
ALTER TABLE T_XBBNHG2_EmpDetails DROP COLUMN teamname;
ALTER TABLE T_XBBNHG2_EmpDetails DROP COLUMN teammanager;
ALTER TABLE T_XBBNHG2_LeadDetails DROP COLUMN teammanager;


