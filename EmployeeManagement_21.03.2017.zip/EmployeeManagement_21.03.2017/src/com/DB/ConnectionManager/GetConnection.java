package com.DB.ConnectionManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetConnection {

	public Connection getConnection() {
		Connection con = null;
		try {
			try {
				// Class.forName("org.apache.derby.jdbc.ClientDriver");
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "mahesh", "mahesh");
	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
