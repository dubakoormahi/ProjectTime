package com.DB.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DB.ConnectionManager.GetConnection;

public class UpdateLocationDAO {
	public boolean insertLocation(String empID, String location, String frmdate, String todate, String team) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		if (conn != null) {
			try {
				PreparedStatement ps = null;
				ps = conn.prepareStatement("insert into T_XBBNHG2_LocationDetails values(?,?,?,?,?)");
				ps.setString(1, empID);
				ps.setString(2, location);
				ps.setString(3, frmdate);
				ps.setString(4, todate);
				ps.setString(5, team);
				ps.executeUpdate();
				ps.close();
				return true;
			} catch (SQLException e1) {
				e1.printStackTrace();
				return false;
			}
		} else {
			System.out.println("connection failed");
			return false;
		}
	}
}