package com.basic.BeanModules;

public class StatusBean {
	private String EmpID;
	private String Location;
	private String FromDate;
	private String ToDate;
	private String bgcolor;
	private String txtcolor;

	public String getBgcolor() {
		return bgcolor;
	}

	public void setBgcolor(String bgcolor) {
		this.bgcolor = bgcolor;
	}

	public String getTxtcolor() {
		return txtcolor;
	}

	public void setTxtcolor(String txtcolor) {
		this.txtcolor = txtcolor;
	}

	public String getEmpID() {
		return EmpID;
	}

	public void setEmpID(String empID) {
		EmpID = empID;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getFromDate() {
		return FromDate;
	}

	public void setFromDate(String fromDate) {
		FromDate = fromDate;
	}

	public String getToDate() {
		return ToDate;
	}

	public void setToDate(String toDate) {
		ToDate = toDate;
	}
}
