--create
create table T_XBBNHG2_EmpCredentials(username varchar(20) primary key,password varchar(20),usertype varchar(20));
create table T_XBBNHG2_EmpDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));
create table T_XBBNHG2_LeadDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));
create table T_XBBNHG2_LocationDetails(empID varchar(20),location varchar(30), frmdate varchar(12), todate varchar(12),team varchar(30));
--altertable
alter table T_XBBNHG2_EmpDetails add teamname varchar2(30);
alter table T_XBBNHG2_LocationDetails add reason varchar2(30);

update T_XBBNHG2_EmpDetails set teamname='TT01' where empid='EM001';
alter table T_XBBNHG2_EmpDetails drop column teammanager;
drop table T_XBBNHG2_ColorMatch;
truncate table T_XBBNHG2_ColorMatch;
create table T_XBBNHG2_ColorMatch(Location varchar(30),color varchar(20),text_color varchar(30));
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('GUWAHATI','TURQUOISE','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('BHUBANESWAR','STEELBLUE','WHITE');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('KOLKATA','TOMATO','WHITE');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('JAIPUR','THISTLE','WHITE');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('NOIDA','TEAL','WHITE');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('GURGAON','ORANGE','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('DELHI','SPRINGGREEN','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('VIJAYAWADA','SALMON','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('VISAKHAPATNAM','ROYALBLUE','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('SECUNDERABAD','ROSYBROWN','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('HYDERABAD','RED','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('COCHIN','VIOLET','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('CHENNAI','YELLOWGREEN','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('MYSORE','PERU','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('BANGALORE','YELLOW','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('BARODA','PURPLE','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('GUJARAT','SIENNA','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('AHMEDABAD','ORANGERED','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('MUMBAI','SANDYBROWN','BLACK');
INSERT INTO T_XBBNHG2_COLORMATCH VALUES('PUNE','WHEAT','BLACK');

--select
select * from T_XBBNHG2_EmpCredentials;
select * from T_XBBNHG2_EmpDetails;
select * from T_XBBNHG2_LeadDetails;
select * from T_XBBNHG2_LocationDetails;

--truncate
truncate table T_XBBNHG2_LeadDetails;
truncate table T_XBBNHG2_EmpDetails;
truncate table T_XBBNHG2_EmpCredentials;
--drop
drop table T_XBBNHG2_LeadDetails;
drop table T_XBBNHG2_EmpDetails;
drop table T_XBBNHG2_EmpCredentials;
----------------------------------------------------------------
alter table T_XBBNHG2_EmpDetails add(lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30),teammanager varchar2(30));
----------------------------------------------------------------
CREATE TABLE T_XBBNHG2_LeadDetails AS (SELECT * FROM T_XBBNHG2_EmpCredentials);
create table T_XBBNHG2_LeadDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));

ALTER TABLE T_XBBNHG2_EmpDetails ADD teamname varchar2(30);
ALTER TABLE T_XBBNHG2_EmpDetails DROP COLUMN teamname;
ALTER TABLE T_XBBNHG2_EmpDetails DROP COLUMN teammanager;
ALTER TABLE T_XBBNHG2_LeadDetails DROP COLUMN teammanager;


