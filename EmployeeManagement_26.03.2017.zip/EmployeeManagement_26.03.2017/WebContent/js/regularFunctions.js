function isNumberKey(evt) {
	var charCode = (evt.which) ? evt.which : event.keyCode;
	if (charCode > 31 && (charCode != 46 && (charCode < 48 || charCode > 57)))
		return false;
	return true;
}
function registerUser() {
	alert("Hai");
}
function validateForm() {
	var pass1 = document.forms["signupform"]["password1"].value;
	var pass2 = document.forms["signupform"]["password2"].value;
	if (pass1 == pass2) {
		return true;
	} else {
		alert("Password doesnot matches");
		return false;
	}
}
function validateUserPwd() {
	var username = document.getElementById("username").value;
	var password = document.getElementById("password").value;
	if (username == "" && password == "") {
		alert("Please enter a Username and password");
		return false;
	} else if (username == "") {
		alert("Please enter a Username");
		return false;
	} else if (password == "") {
		alert("Please enter a password");
		return false;
	} else {
		return true;
	}
}
function validateUser() {
	var username = document.getElementById("username").value;
	if (username == "") {
		alert("Please enter a Username");
		return false;
	} else {
		return true;
	}
}