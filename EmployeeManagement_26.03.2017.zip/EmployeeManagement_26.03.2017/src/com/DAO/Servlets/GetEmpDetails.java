package com.DAO.Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DB.util.GetEmpDetailsUtil;
import com.basic.BeanModules.EmpDetailsBean;

public class GetEmpDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public GetEmpDetails() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<EmpDetailsBean> ltt = new ArrayList<>();
		GetEmpDetailsUtil get = new GetEmpDetailsUtil();
		ltt = get.getDetails((String) request.getSession().getAttribute(
				"teamName"));
		request.setAttribute("empDetailslist", ltt);
	}

}
