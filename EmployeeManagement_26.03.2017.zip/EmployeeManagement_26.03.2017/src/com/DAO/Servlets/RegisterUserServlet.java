package com.DAO.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DB.util.RegisterUser;

public class RegisterUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegisterUserServlet() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		if (registerUser(request)) {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('User Registered!!! Good to go!!!');");
			out.println("location='Login.jsp';");
			out.println("</script>");
		} else {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('You are not Registered at this time!!! Sorry try again later');");
			out.println("location='register.jsp';");
			out.println("</script>");
		}
	}

	private boolean registerUser(HttpServletRequest request) {
		String empID = request.getParameter("empID");
		String namePerson = request.getParameter("FirstName");
		String emailID = request.getParameter("emailid");
		String LastName = request.getParameter("LastName");
		String passWord = request.getParameter("password1");
		String userType = request.getParameter("utype");
		String contactno = request.getParameter("contactno");
		String Location = request.getParameter("CLocation");
		String teamname = request.getParameter("Tname");
		if (RegisterUser.registerUser(empID, namePerson, emailID, passWord, userType, LastName, contactno, Location,
				teamname)) {
			return true;
		} else {
			return false;
		}
	}
}
