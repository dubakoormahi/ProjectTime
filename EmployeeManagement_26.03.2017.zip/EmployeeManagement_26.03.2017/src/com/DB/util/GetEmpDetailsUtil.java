package com.DB.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.DB.ConnectionManager.GetConnection;
import com.basic.BeanModules.EmpDetailsBean;

public class GetEmpDetailsUtil {
	public List<EmpDetailsBean> getDetails(String teamname) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		List<EmpDetailsBean> Emplist = new ArrayList<>();
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = "select * from T_XBBNHG2_EmpDetails where teamname='"
						+ teamname + "' order by empid";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					EmpDetailsBean sb = new EmpDetailsBean();
					sb.setEmpID(rs.getString("empid"));
					sb.setName(rs.getString("name"));
					sb.setEmailID(rs.getString("emailid"));
					sb.setContactNo(rs.getString("contactno"));
					sb.setBaseLoc(rs.getString("location"));
					Emplist.add(sb);
				}
				return Emplist;
			} catch (Exception e) {
				return null;
			} finally {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return Emplist;
	}
}
