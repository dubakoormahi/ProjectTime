package com.DB.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.DB.ConnectionManager.GetConnection;

public class LoginUser {
	public static String loginUser(String userName, String passWord) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String usertype = null;
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = "select usertype as countnum from EmpCredentials where username='"
						+ userName + "'and password='" + passWord + "'";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					usertype = rs.getString("countnum");
				}
			} catch (Exception e) {
				return null;
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		if (usertype == null)
			return null;
		else
			return usertype;
	}

	@SuppressWarnings("unused")
	public static String[] getUserName(String userName, String uType) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		Statement stmt = null;
		ResultSet rs = null;
		String arr[] = new String[3];
		if (conn != null) {
			try {
				stmt = conn.createStatement();
				String SQLSelectQuery = null;
				if (uType.equalsIgnoreCase("leader"))
					SQLSelectQuery = "select name as countnum,teamname as tmname,location from LeadDetails where empid='"
							+ userName + "'";
				else if (uType.equalsIgnoreCase("member"))
					SQLSelectQuery = "select name as countnum,teamname as tmname,location from EmpDetails where empid='"
							+ userName + "'";
				rs = stmt.executeQuery(SQLSelectQuery);
				while (rs.next()) {
					arr[0] = rs.getString("countnum");
					arr[1] = rs.getString("tmname");
					arr[2] = rs.getString("location");
				}
			} catch (Exception e) {
				return null;
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		if (arr == null)
			return null;
		else
			return arr;
	}

}
