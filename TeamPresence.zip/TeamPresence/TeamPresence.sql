--create
create table EmpCredentials(username varchar(20) primary key,password varchar(20),usertype varchar(20));
create table EmpDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));
create table LeadDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));
create table ColorMatch(Location varchar(30),color varchar(20),text_color varchar(30));
create table LocationDetails(empID varchar(20),location varchar(30), frmdate varchar(12), todate varchar(12),team varchar(30));
--altertable
alter table EmpDetails add teamname varchar2(30);
alter table LocationDetails add reason varchar2(30);

update EmpDetails set teamname='TT01' where empid='EM001';
alter table EmpDetails drop column teammanager;



INSERT INTO COLORMATCH VALUES('GUWAHATI','TURQUOISE','BLACK');
INSERT INTO COLORMATCH VALUES('BHUBANESWAR','STEELBLUE','WHITE');
INSERT INTO COLORMATCH VALUES('KOLKATA','TOMATO','WHITE');
INSERT INTO COLORMATCH VALUES('JAIPUR','THISTLE','WHITE');
INSERT INTO COLORMATCH VALUES('NOIDA','TEAL','WHITE');
INSERT INTO COLORMATCH VALUES('GURGAON','ORANGE','BLACK');
INSERT INTO COLORMATCH VALUES('DELHI','SPRINGGREEN','BLACK');
INSERT INTO COLORMATCH VALUES('VIJAYAWADA','SALMON','BLACK');
INSERT INTO COLORMATCH VALUES('VISAKHAPATNAM','ROYALBLUE','BLACK');
INSERT INTO COLORMATCH VALUES('SECUNDERABAD','ROSYBROWN','BLACK');
INSERT INTO COLORMATCH VALUES('HYDERABAD','RED','BLACK');
INSERT INTO COLORMATCH VALUES('COCHIN','VIOLET','BLACK');
INSERT INTO COLORMATCH VALUES('CHENNAI','YELLOWGREEN','BLACK');
INSERT INTO COLORMATCH VALUES('MYSORE','PERU','BLACK');
INSERT INTO COLORMATCH VALUES('BANGALORE','YELLOW','BLACK');
INSERT INTO COLORMATCH VALUES('BARODA','PURPLE','BLACK');
INSERT INTO COLORMATCH VALUES('GUJARAT','SIENNA','BLACK');
INSERT INTO COLORMATCH VALUES('AHMEDABAD','ORANGERED','BLACK');
INSERT INTO COLORMATCH VALUES('MUMBAI','SANDYBROWN','BLACK');
INSERT INTO COLORMATCH VALUES('PUNE','WHEAT','BLACK');

--select
select * from EmpCredentials;
select * from EmpDetails;
select * from LeadDetails;
select * from LocationDetails;
select * from LocationDetails where empid='EM001';

--truncate
truncate table LeadDetails;
truncate table EmpDetails;
truncate table EmpCredentials;
truncate table LocationDetails;
truncate table ColorMatch;
--drop
drop table EmpCredentials;
drop table EmpDetails;
drop table LeadDetails;
drop table LocationDetails;
drop table ColorMatch;
----------------------------------------------------------------
alter table EmpDetails add(lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30),teammanager varchar2(30));
----------------------------------------------------------------
CREATE TABLE LeadDetails AS (SELECT * FROM EmpCredentials);
create table LeadDetails(empid varchar(20) primary key,name varchar(30),emailid varchar(30),lastname varchar(50),contactno varchar(10),
location varchar(30),teamname varchar2(30));

ALTER TABLE EmpDetails ADD teamname varchar2(30);
ALTER TABLE EmpDetails DROP COLUMN teamname;
ALTER TABLE EmpDetails DROP COLUMN teammanager;
ALTER TABLE LeadDetails DROP COLUMN teammanager;


select * from LocationDetails where frmdate between '2017-01-01' and '2017-03-01' or todate between '2017-01-01' and '2017-03-01'
