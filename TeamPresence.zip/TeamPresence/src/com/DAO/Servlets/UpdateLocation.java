package com.DAO.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DB.util.UpdateLocationDAO;

public class UpdateLocation extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UpdateLocation() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String empID = request.getParameter("empID");
		String Location = request.getParameter("Location");
		String reason = request.getParameter("reason");
		String frmdate = request.getParameter("frmdate");
		String todate = request.getParameter("todate");
		String team = request.getParameter("team");
		UpdateLocationDAO ul = new UpdateLocationDAO();
		try {
			int status = ul.insertLocation(empID, Location, frmdate, todate,
					team, reason);
			String utt = request.getSession().getAttribute("userType")
					.toString();
			if (utt.equalsIgnoreCase("leader")) {
				if (status == 1) {
					out.print("<script>");
					out.print("alert('Updated Employee Status');");
					out.print("location.href='LeaderDashboard.jsp';");
					out.print("</script>");
				} else if (status == -1) {
					out.print("<script>");
					out.print("alert('Already Status available for these dates');");
					out.print("location.href='LeaderDashboard.jsp';");
					out.print("</script>");
				} else if (status == -2) {
					out.print("<script>");
					out.print("alert('There is a database error');");
					out.print("location.href='LeaderDashboard.jsp';");
					out.print("</script>");
				} else if (status == 0) {
					out.print("<script>");
					out.print("alert('There is a Exception');");
					out.print("location.href='LeaderDashboard.jsp';");
					out.print("</script>");
				} else {
					out.print("<script>");
					out.print("alert('Not Updated');");
					out.print("location.href='LeaderDashboard.jsp';");
					out.print("</script>");
				}
			} else {
				if (status == 1) {
					out.print("<script>");
					out.print("alert('Updated your Status');");
					out.print("location.href='MemberDashboard.jsp';");
					out.print("</script>");
				} else if (status == -1) {
					out.print("<script>");
					out.print("alert('Already Status available for these dates');");
					out.print("location.href='MemberDashboard.jsp';");
					out.print("</script>");
				} else if (status == -2) {
					out.print("<script>");
					out.print("alert('There is a database error');");
					out.print("location.href='MemberDashboard.jsp';");
					out.print("</script>");
				} else if (status == 0) {
					out.print("<script>");
					out.print("alert('There is a Exception');");
					out.print("location.href='MemberDashboard.jsp';");
					out.print("</script>");
				} else {
					out.print("<script>");
					out.print("alert('Not Updated');");
					out.print("location.href='MemberDashboard.jsp';");
					out.print("</script>");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}