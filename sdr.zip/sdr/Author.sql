create table author_1357981
(
authorId  number(3) primary key,
authorName varchar2(30) not null

)

create table book_1357981(
bookId number(3) primary key,
bookTitle varchar2(50) not null,
bookType varchar2(30) not null,
bookCost number(5,2)not null,
authorId number(3) not null,
foreign key (authorId) references author_1357981(authorId)


)

DROP TABLE book_1357981
DROP TABLE author_1357981

insert into author_1357981 values(100,'Henry Fielding');
insert into author_1357981 values(101,'Jane Austen');
insert into author_1357981 values(102,'Herman Melville');


insert into book_1357981 values(1,'The Masquerade','poem',2.00,100)
insert into book_1357981 values(2,'Pasquin','play',5.00,100)
insert into book_1357981 values(3,'The Covent-Garden Journal','periodical',6.50,100)
insert into book_1357981 values(4,'Sense and Sensibility','Novel',10.00,101)
insert into book_1357981 values(5,'Pride and Prejudice','Novel',10.00,101)
insert into book_1357981 values(6,'Moby-Dick Novel','Novel',5.00,102)
insert into book_1357981 values(7,'Battle Pieces and Aspects of the War','poem',5.00,102)


select a.authorName,b.bookTitle,b.bookType,b.bookCost from author_1357981 a inner join BOOK_1357981  b on a.authorId=b.authorId order by a.authorId




