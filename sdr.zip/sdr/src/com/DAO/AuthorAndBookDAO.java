package com.DAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import com.Bean.Author;
import com.Bean.Book;
import com.Util.DatabaseUtil;

public class AuthorAndBookDAO {
	
	
	public ArrayList<Author> getDetail() throws SQLException
	{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		ArrayList<Author> a=new ArrayList<>();
		ArrayList<Book> b=new ArrayList<>();
		
		
		try {
			con=DatabaseUtil.getConnection();
			pst=con.prepareStatement("select a.authorName,b.bookTitle,b.bookType,b.bookCost from author_ a inner join BOOK_  b on a.authorId=b.authorId order by a.authorId ");
			
			rs=pst.executeQuery();
			while(rs.next())
			{
				Author a1=new Author();
				Book b1=new Book();
				a1.setAuthorName(rs.getString(1));
				b1.setBookTitle(rs.getString(2));
				b1.setBookType(rs.getString(3));
				b1.setBookCost(rs.getDouble(4));
				a1.getB().add(b1);
				
				
				a.add(a1);
				
				
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			if(con!=null)
				DatabaseUtil.closeConnection(con);
			if(pst!=null)
				pst.close();
			if(rs!=null)
				rs.close();
		}
		
		
		
		
		return a;
		
		
	}

	public ArrayList<Book> getBookDetail() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		
		ArrayList<Book> b=new ArrayList<>();
		
		
		try {
			con=DatabaseUtil.getConnection();
			pst=con.prepareStatement("select b.bookTitle,b.bookType,b.bookCost from  BOOK_  b  ");
			
			rs=pst.executeQuery();
			while(rs.next())
			{
				
				Book b1=new Book();
				
				b1.setBookTitle(rs.getString(1));
				b1.setBookType(rs.getString(2));
				b1.setBookCost(rs.getDouble(3));
				b.add(b1);
				
				
				
				
				
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			if(con!=null)
				DatabaseUtil.closeConnection(con);
			if(pst!=null)
				pst.close();
			if(rs!=null)
				rs.close();
		}
		
		return b;
	}

	
	
	

}
