package com.Service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.Bean.Author;
import com.Bean.Book;
import com.DAO.AuthorAndBookDAO;

public class AuthorAndBookService {
	
	public ArrayList<Author> getDetails() 
	{
		
		AuthorAndBookDAO aDAO=new AuthorAndBookDAO();
		ArrayList<Author> a=null;
		try {
			a = aDAO.getDetail();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
		
	}
	
	public ArrayList<Book> getBookDetails()
	{
		AuthorAndBookDAO aDAO=new AuthorAndBookDAO();
		ArrayList<Book> b=null;
		try {
			b = aDAO.getBookDetail();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		
	}

}
