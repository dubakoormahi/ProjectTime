create table shoe(
shoeid number not null primary key ,
name varchar(20) not null,
price number not null
)
select * from shoe