package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {
	static Connection con = null;
	
	public static Connection getConnection() {
	String url = "jdbc:oracle:thin:@intvmoradb04:1521:ORAJAVADB";
	String userid = "TVM1718_TVM07_TJA44_DEV";
	String pass = "tcstvm07";
	try{
		Class.forName("oracle.jdbc.OracleDriver");
		con = DriverManager.getConnection(url,userid,pass);
	}catch(SQLException e){
		e.printStackTrace();
	}catch(ClassNotFoundException e){
		e.printStackTrace();
	}
	
		return con;
	}
	public static void closeConnection(Connection con) {
		try{
		con.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
}
