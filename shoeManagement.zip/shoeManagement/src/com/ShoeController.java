package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShoeController
 */
@WebServlet("/ShoeController")
public class ShoeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ShoeController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getParameter("action");
		if(action.equals("Add")){
			RequestDispatcher rd = request.getRequestDispatcher("Add.jsp");
			rd.forward(request, response);
		}
		if(action.equals("Add1")){
			int id = Integer.parseInt(request.getParameter("shoeid"));
			String name = request.getParameter("name");
			int price = Integer.parseInt(request.getParameter("price"));
			ShoeService sr = new ShoeService();
			ShoeBean s = new ShoeBean();
			s.setShoeid(id);
			s.setName(name);
			s.setPrice(price);
			boolean b = sr.addShoe(s);
			if(b==true){
				RequestDispatcher rd = request.getRequestDispatcher("Added.jsp");
				rd.forward(request, response);
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
			}
			
		}
		if(action.equals("Search")){
			RequestDispatcher rd = request.getRequestDispatcher("Search.jsp");
			rd.forward(request, response);
		}
		if(action.equals("Search1")){
			int id =Integer.parseInt(request.getParameter("shoeid"));
			ShoeBean sb = new ShoeBean();
			ShoeService s = new ShoeService();
			sb = s.searchShoe(id);
			PrintWriter out = response.getWriter();
			out.println(sb);
			if(sb != null){
				RequestDispatcher rd = request.getRequestDispatcher("Searched.jsp");
				rd.forward(request, response);
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
			}
		}
		if(action.equals("delete"))
		{
			System.out.println("hai");
			RequestDispatcher rd=request.getRequestDispatcher("delete.jsp");
			rd.forward(request,response);
		}
		if(action.equals("delete1")){
			int id = Integer.parseInt(request.getParameter("shoeid"));
			ShoeService sr = new ShoeService();
			boolean b = sr.deleteShoe(id);
			if(b == true){
				RequestDispatcher rd = request.getRequestDispatcher("deleted.jsp");
				rd.forward(request, response);
			}
			else{
				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				rd.forward(request, response);
			}
		}
		if(action.equals("update"))
		{
			RequestDispatcher rd= request.getRequestDispatcher("update1.jsp");
			rd.forward(request,response);
		}
		if(action.equals("update1"))
		{
			int id=Integer.parseInt(request.getParameter("shoeid"));
			
			ShoeService sr=new ShoeService();
			ShoeBean s=new ShoeBean();
			s=sr.searchShoe(id);
			request.setAttribute("string",s);
			if(s!=null)
			{
				RequestDispatcher rd= request.getRequestDispatcher("update2.jsp");
				rd.forward(request,response);
				
			}
			
		}
		if(action.equals("update2"))
		{
			ShoeService sr=new ShoeService();
			ShoeBean s=new ShoeBean();
			s.setPrice(Integer.parseInt(request.getParameter(("shoeid"))));
			s.setName(request.getParameter("name"));
			s.setPrice(Integer.parseInt(request.getParameter("price")));
			boolean b=sr.updateShoe(s);
			if(b==true)
			{
				RequestDispatcher rd= request.getRequestDispatcher("update3.jsp");
				rd.forward(request,response);
			}
		}
	}

}
