package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ShoeDAO {
	Connection con = null;
	
	public boolean addShoe(ShoeBean sb){
		boolean b = false;
		con = DatabaseUtil.getConnection();
		try{
			PreparedStatement pst = con.prepareStatement("insert into shoe values(?,?,?)");
			pst.setInt(1, sb.getShoeid());
			pst.setString(2, sb.getName());
			pst.setInt(3, sb.getPrice());
			int i = pst.executeUpdate();
			if(i == 1){
				b = true;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(con != null){
				DatabaseUtil.closeConnection(con);
			}
		}
		return b;
	
	}
	
	public ShoeBean searchShoe(int shoeid){
		con = DatabaseUtil.getConnection();
		ShoeBean s = new ShoeBean();
		try{
			PreparedStatement pst = con.prepareStatement("select * from shoe where shoeid = ?");
			pst.setInt(1,shoeid);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				
				s.setShoeid(rs.getInt("shoeid"));
				s.setName(rs.getString("name"));
				s.setPrice(rs.getInt("price"));
			}
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(con != null)
				DatabaseUtil.closeConnection(con);
		}
		return s;
		
	}
	
	public boolean deleteShoe(int id){
		boolean b = false;
		con = DatabaseUtil.getConnection();
		
		try{
			PreparedStatement pst = con.prepareStatement("Delete from shoe where shoeid = ?");
			pst.setInt(1,id);
			int i = pst.executeUpdate();
			if(i == 1){
				b = true;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(con != null)
				DatabaseUtil.closeConnection(con);
			}
		return b;
		}
	
	public boolean updateShoe(ShoeBean s){
		con = DatabaseUtil.getConnection();
		boolean b = false;
		try{
			PreparedStatement pst = con.prepareStatement("update shoe set name = ?,price=? where shoeid = ? ");
			pst.setString(1,s.getName());
			pst.setInt(2, s.getPrice());
			pst.setInt(3,s.getShoeid());
			int i = pst.executeUpdate();
			if(i == 1){
				b = true;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			if(con != null){
				DatabaseUtil.closeConnection(con);
			}
		}
		return b;
	}
	}
	


