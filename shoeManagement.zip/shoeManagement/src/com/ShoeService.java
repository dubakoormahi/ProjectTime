package com;

public class ShoeService {
	
	ShoeDAO dao = new ShoeDAO();
	public boolean addShoe(ShoeBean sb){
		return dao.addShoe(sb);
	}
	public ShoeBean searchShoe(int shoeid){
		return dao.searchShoe(shoeid);
	}
	public boolean deleteShoe(int id){
		return dao.deleteShoe(id);
	}
	public boolean updateShoe(ShoeBean s){
		return dao.updateShoe(s);
	}

}
