package com.DB.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.DB.ConnectionManager.GetConnection;

public class RegisterUser {

	public static boolean registerUser(String empID, String namePerson, String emailID, String passWord,
			String userType, String lastName, String contactno, String location, String teamname) {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		int x = 0, z = 0;
		if (conn != null) {
			try {
				PreparedStatement ps = null;
				if (userType.equalsIgnoreCase("leader")) {
					ps = conn.prepareStatement("insert into LeadDetails values(?,?,?,?,?,?,?)");
				} else if (userType.equalsIgnoreCase("member")){
					ps = conn.prepareStatement("insert into EmpDetails values(?,?,?,?,?,?,?)");
				}
				ps.setString(1, empID);
				ps.setString(2, namePerson);
				ps.setString(3, emailID);
				ps.setString(4, lastName);
				ps.setString(5, contactno);
				ps.setString(6, location);
				ps.setString(7, teamname);
				x = ps.executeUpdate();
				ps.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			try {
				PreparedStatement ps2 = conn.prepareStatement("insert into EmpCredentials values(?,?,?)");
				ps2.setString(1, empID);
				ps2.setString(2, passWord);
				ps2.setString(3, userType);
				z = ps2.executeUpdate();
				ps2.close();
			} catch (Exception e2) {
				System.out.println(e2);
				e2.printStackTrace();
			} finally {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} else {
			System.out.println("connection failed");
			return false;
		}
		if (x > 0 && z > 0) {
			return true;
		} else {
			return false;
		}
	}

}
