package com.DB.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.DB.ConnectionManager.GetConnection;

public class UpdateLocationDAO {
	public int insertLocation(String empID, String location, String frmdate,
			String todate, String team, String reason) throws SQLException {
		GetConnection get = new GetConnection();
		Connection conn = get.getConnection();
		if (conn != null) {
			Statement stmt = null;
			stmt = conn.createStatement();
			ResultSet stt = stmt
					.executeQuery("select * from LocationDetails where empid='"
							+ empID + "' and (frmdate>='" + frmdate
							+ "' and todate<='" + frmdate + "')or (todate<='"
							+ todate + "' and frmdate>='" + todate + "')");

			if (stt.next()) {
				stt.close();
				stmt.close();
				return -1;
			} else {
				try {
					PreparedStatement ps = null;
					ps = conn
							.prepareStatement("insert into LocationDetails values(?,?,?,?,?,?)");
					ps.setString(1, empID);
					ps.setString(2, location);
					ps.setString(3, frmdate);
					ps.setString(4, todate);
					ps.setString(5, team);
					ps.setString(6, reason);
					ps.executeUpdate();
					ps.close();
					return 1;
				} catch (SQLException e1) {
					e1.printStackTrace();
					return 0;
				}
			}
		} else {
			System.out.println("connection failed");
			return -2;
		}
	}
}